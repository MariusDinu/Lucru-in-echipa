import java.util.Arrays;

public class Lab {
    public int[][] maze;
    public int[] finalStage=new int[2];
    public int[] startStage=new int[2];
    public int[] lastPosition=new int[2];
    public Lab(int[][] maze) {
        this.maze = maze;
    }
public int[] resultMaze(){
        int startX=0;
        int startY=0;
        boolean check=true;
        int sizeMaze= maze.length-1;
        int direction;
        System.out.println(sizeMaze);

        while(check) {
            if (maze[startX][startY]==1) {
                direction = 1;
                lastPosition[0] = startX;
                lastPosition[1] = startY;
                System.out.println(Arrays.toString(lastPosition));
                startStage[0]=startX;
                startStage[1]=startY;

                /*if (direction == 0)
                { if(checkValid(startX-1,startY))
                {startX--; direction=0;} else {direction++;}
                }
                else
                if(direction==1)
                {
                    if(checkValid(startX,startY+1))
                    {startY++; direction=0;} else {direction++;}
                }
                else
                if(direction==2)
                {
                    if(checkValid(startX+1,startY))
                {startX++; direction=0;} else {direction++;}
                }
                else
                if(direction==3)
                {
                    if(checkValid(startX,startY-1))
                {startY--; direction=0;} else {System.out.println("Nu ai rezolvare");}
                }
*/
check=false;
                }
             else {
                System.out.println(startY); if(startY!=sizeMaze)startY++; else {startY=0;
                    if(startX!=sizeMaze)startX++; else check=false;}

            }
        }
        return startStage;
}


    public boolean checkValid(int a,int b){
        if(maze[a][b]==1)
            return true;
        return false;

    }

    public void setFinalStage(int a,int b){
        finalStage[0]=a;
        finalStage[1]=b;
    }
    public boolean checkStage (int[] actualStage){
      if((actualStage[0]==finalStage[0])&&(actualStage[1]==finalStage[1]))
           return true;
       return false;
    }



}
